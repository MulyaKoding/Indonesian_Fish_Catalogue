package com.id.soulution.fishcatalog.modules.items

data class UserItem (
    var uri: Int,
    var label: String = ""
)