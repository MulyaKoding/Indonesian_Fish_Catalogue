package com.id.soulution.fishcatalog.modules.items

data class AccountMenuItem (
    var label: String = ""
)